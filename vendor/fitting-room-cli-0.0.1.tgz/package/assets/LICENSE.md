# Brand assets, not under Apache-2.0

`favicon.ico` and `apple-touch-icon.png` in this folder are copies of the Fitting Room brand assets in `docs/brand/` (`favicon.ico` and `favicon-180.png`). They are governed by `docs/brand/LICENSE.md` in the repository (https://github.com/benpiticaru/fittingroom/blob/main/docs/brand/LICENSE.md), and are excluded from the Apache-2.0 license that covers the rest of this package.

The terms of `docs/brand/LICENSE.md`, reproduced verbatim so they travel with the package ("this folder" means `docs/brand/` in the repository):

The name "Fitting Room", the frame-and-pin mark, the lockups, favicons and social preview in this folder are trademarks and brand assets of Benjamin Piticaru / Cornerstone Digital Systems. They are included here so the project's own panel, docs and site can use them, and so forks can see what to replace.

You may:
- build and run this software, including the panel, with these assets as shipped;
- refer to the project by name in text ("works with Fitting Room", "a Fitting Room fixture bundle");
- reproduce the mark unmodified when linking to or writing about the project.

You may not, without written permission:
- ship a modified or forked version of this software under the name "Fitting Room" or with this mark;
- use the name or mark for a product, service, domain or package in a way that suggests it is this project or endorsed by it;
- alter the mark (colours, proportions, the open corner, the pin) and present the result as the Fitting Room mark.

Forks: rename and replace the assets in this folder; `README.md` describes what each file is for. The rest of the repository stays Apache-2.0 and needs no change.
